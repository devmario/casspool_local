cp src/main/java/com/vanillabreeze/$1 src/main/java/com/vanillabreeze/$2
