#!/bin/bash

mvn compile
if [ $? != 0 ]; then
	echo "[casspool_tool fail compile maven]"
	exit $?
fi
echo "[casspool_tool success compile maven]"
mvn package
if [ $? != 0 ]; then
	echo "[casspool_tool fail package maven]"
	exit $?
fi
echo "[casspool_tool success package maven]"
exit $?
