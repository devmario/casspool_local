casspool_local
==============

casssandra pool local
